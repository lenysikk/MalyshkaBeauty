package io.proj3ct.MilashkaBeautyBot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MilashkaBeautyBotApplication {

	public static void main(String[] args) {
		SpringApplication.run(MilashkaBeautyBotApplication.class, args);
	}

}
