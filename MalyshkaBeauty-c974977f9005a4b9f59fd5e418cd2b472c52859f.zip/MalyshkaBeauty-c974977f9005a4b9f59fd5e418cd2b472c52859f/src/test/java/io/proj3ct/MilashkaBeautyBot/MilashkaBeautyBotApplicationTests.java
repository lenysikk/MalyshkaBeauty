package io.proj3ct.MilashkaBeautyBot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MilashkaBeautyBotApplicationTests {

	@Test
	void contextLoads() {
	}

}
